from setuptools import setup
# -*- coding: latin-1 -*-

setup(

    name="calculosbasicosmatematicos",
    version="1.0",
    description="calculo las funciones basicas, suma, resta y multiplicacion",
    author="Alexander Del Risco",
    author_mail="tutorizados@pildorasinformaticas.es",
    url="www.pildorasinformaticas.es",
    packages=["moduloMatematico", "moduloMatematico.calculosBasicos"]
)